import type { Config } from 'tailwindcss/types/config';

export default {
  theme: {
    extend: {},
  },
  plugins: [],
} as Omit<Config, 'content'>;
