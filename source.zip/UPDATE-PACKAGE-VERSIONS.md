For update package version in all ```package.json``` files use this command in root:

FOR WINDOWS YOU NEED TO USE E.G ```GIT BASH``` CONSOLE OR OTHER WHICH SUPPORT UNIX COMMANDS
```bash
pnpm update-version <new_version>
```

If script was run successfully you will see ```Updated versions to <new_version>```
